-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Des 2020 pada 07.49
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `keepbeautie`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `laris`
--

CREATE TABLE `laris` (
  `id` int(6) UNSIGNED NOT NULL,
  `varian` varchar(30) NOT NULL,
  `terjual` varchar(30) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `laris`
--

INSERT INTO `laris` (`id`, `varian`, `terjual`, `reg_date`) VALUES
(1, 'Romansa', '203', '2020-12-23 13:54:27'),
(2, 'Fantasia', '116', '2020-12-23 13:54:27'),
(3, 'Charming', '456', '2020-12-23 13:54:27'),
(4, 'Freshy', '433', '2020-12-23 13:54:27');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `laris`
--
ALTER TABLE `laris`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `laris`
--
ALTER TABLE `laris`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
