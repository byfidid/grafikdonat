<!DOCTYPE html>
<html>
<head>
  <title>FidyaFarasalsabila_180155201014</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap.min.css"> 
</head>
<body>
 
<div class="container">
  <h2>Grafik Survei Varian Terlaris Keepbeautie</h2>
    <div class="col-sm-6">
      <div class="panel-group">
        <div class="panel panel-default">
          <div class="panel-heading">Grafik Lingkaran Donat</div>
          <div class="panel-body"><iframe src="doughnut.php" width="100%" height="300"></iframe></div>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
