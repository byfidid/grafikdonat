<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "keepbeautie";
// Membuat Koneksi
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Memeriksa koneksi
if (!$conn){
die("Connection failed: " . mysqli_connect_error());
}
// SQL untuk membuat tabel
$sql = "CREATE TABLE laris (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
varian VARCHAR(30) NOT NULL,
terjual VARCHAR(30) NOT NULL,
reg_date TIMESTAMP
)";
if (mysqli_query($conn, $sql)) {
echo "Table created successfully";
} else {
echo "Error creating table: " . mysqli_error($conn);
}
mysqli_close($conn);
?>