<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "keepbeautie";
// Membuat Koneksi
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Memeriksa Koneksi
if (!$conn){
	die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO laris (id, varian, terjual)
VALUES ('1', 'Romansa', '203');";
$sql = "INSERT INTO laris (id, varian, terjual)
VALUES ('2', 'Fantasia', '116');";
$sql = "INSERT INTO laris (id, varian, terjual)
VALUES ('3', 'Charming', '456');";
$sql = "INSERT INTO laris (id, varian, terjual)
VALUES ('4', 'Freshy', '433');";

if (mysqli_multi_query($conn, $sql)) {
echo "New records created successfully";
} else {
echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>